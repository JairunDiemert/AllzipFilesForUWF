package studentLab4;
/**
* A class to test the MonitoredStudent class.
* @author Jairun Diemert
* @version 1.0
*
* COP3022	Lab #: 4
* File Name: MonitoredStudentTester.java
*/
import java.util.Scanner;

public class MonitoredStudentTester {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner keyboard = new Scanner(System.in);
		String repeat = "y";
		int currentScore = 0;

		System.out.print("Enter Student's name: ");
		String sName = keyboard.nextLine();
		System.out.print("Enter minimum passing average: ");
		int minAvg = keyboard.nextInt();

		MonitoredStudent student1 = new MonitoredStudent(sName, minAvg);

		do {
			System.out.print("Enter quiz score: ");
			currentScore = keyboard.nextInt();

			student1.addQuiz(currentScore);

			System.out.print("Do you wish to enter another score, (Enter y for Yes, n for no: ");

			keyboard.nextLine();
			repeat = keyboard.nextLine();

		} while (!repeat.equalsIgnoreCase("n"));

		String studName = student1.getName();
		double totalScore = student1.getTotalScore();
		double avgScore = student1.getAverageScore();

		System.out.printf("%s's total quiz score is: %,2f and average quiz score is: %6.2f \n", studName, totalScore,
				avgScore);
		if (student1.isOffProbation()) {
			System.out.printf("%s's probation status: OFF\n",studName);
		}
		else {
			System.out.printf("%s's probation status: ON\n",studName);
		}

		MonitoredStudent student2 = new MonitoredStudent();

		student2.setName("Joe");
		System.out.println("Testing default constructor and setName method " + student2.getName());

	}

}
