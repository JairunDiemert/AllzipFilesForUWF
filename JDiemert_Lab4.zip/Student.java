package studentLab4;

/**
 * Student can be created, and details added.
 * 
 * @author Jairun Diemert
 * @version 1.0
 * 
 * COP3022 Lab #: 4 
 * File Name: Student.java
 */
public class Student {
	/** Student name */
	private String name;

	/** Total of Quiz Scores */
	private double totalScore;

	/** Number of Quizzes Taken */
	private int quizCount;

	/**
	 * Constructs a student using default values.
	 */
	public Student() {
		name = "";
		totalScore = 0;
		quizCount = 0;
	}

	/**
	 * Constructs a student with a given name.
	 * 
	 * @param n the name
	 */
	public Student(String n) {
		name = n;
		totalScore = 0;
		quizCount = 0;
	}

	/**
	 * Sets the student name
	 * 
	 * @param aName the student's name
	 */
	public void setName(String aName) {

		name = aName;

	}

	/**
	 * Gets the name of this student.
	 * 
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Adds a quiz score. Test score for valid score inclusive(0 -100)
	 * 
	 * @param score the score to add
	 */
	public void addQuiz(int score) {
		if (score >= 0 && score <= 100) {
			totalScore = totalScore + score;
			quizCount = quizCount + 1;
		} else {
			System.out.println("Score must be between 0 and 100, inclusive");

		}
	}

	/**
	 * Gets the sum of all quiz scores.
	 * 
	 * @return the total score
	 */
	public double getTotalScore() {
		return totalScore;
	}

	/**
	 * Gets the average of all quiz scores.
	 * 
	 * @return the average score
	 */
	public double getAverageScore() {
		return totalScore / quizCount;
	}

}
