package studentLab4;
/**
 * MonitoredStudent can be created, and details added.
 * 
 * @author Jairun Diemert
 * @version 1.0
 * 
 * COP3022 Lab #: 4 
 * File Name: MonitoredStudent.java
 */
public class MonitoredStudent extends Student {
	
	/**
	 * Minimum passing quiz average
	 */
	private int minPassingAvg;
	
	/**
	 * Default constructor 
	 */
	public MonitoredStudent() {
		super();
		minPassingAvg = 0;
	}

	/**
	 * Parameterized constructor 
	 * @param n name
	 * @param minAvg minimum quiz average
	 */
	public MonitoredStudent(String n, int minAvg) {
		super(n);
		minPassingAvg = minAvg;
	}

	/**
	 * returns the minimum passing quiz average
	 * @return minimum passing quiz average
	 */
	public int getMinPassingAvg() {
		return minPassingAvg;
	}

	/**
	 * Set the minimum quiz average
	 * @param minAvg quiz score
	 */
	public void setMinPassingAvg(int minAvg) {
		minPassingAvg = minAvg;
	}
	/**
	 * Compares students quiz average to the minimum
	 * @return true if above or equal to average
	 */
	public Boolean isOffProbation() {
		Boolean result = false;
		if (getAverageScore() >= getMinPassingAvg()) {
			result = true;
		}
		return result;
	}

}
