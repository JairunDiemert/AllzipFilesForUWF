/**
The Enumerate interface handles enumeration
@author Jairun Diemert
@version 1.0

COP3022	Lab #: 8
File Name: Enumerate.java
*/  
interface Enumerate {
	public Boolean hasNext(int i);

	public Object getNext(int i);
}
