/**
The NameCollectionTester tests the NameCollection Class
@author Jairun Diemert
@version 1.0

COP3022	Lab #: 8
File Name: NameCollectionTester.java
*/  
public class NameCollectionTester {

	public static void main(String[] args) {
		String[] names = { "joe", "ann", "jack", "kim", "jack" };
		NameCollection nameList = new NameCollection(names);
		for (int i = 0; i < names.length + 2; i++) {
			System.out.print("Has next? " + nameList.hasNext(i));
			System.out.println(" Get next: " + nameList.getNext(i));
		}
	}
}
