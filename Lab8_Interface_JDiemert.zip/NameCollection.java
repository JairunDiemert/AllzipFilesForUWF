/**
The NameCollection class handles name lists
@author Jairun Diemert
@version 1.0

COP3022	Lab #: 8
File Name: NameCollection.java
*/  
public class NameCollection implements Enumerate {
	String[] names;

	public NameCollection(String[] names) {
		this.names = names;
	}

	public Boolean hasNext(int i) {
		{
			if (i < names.length) {
				return true;
			} else {
				return false;
			}
		}

	}

	public Object getNext(int i) {
		if (hasNext(i)) {
			return (Object) names[i];
		} else {
			return 0;
		}
	}

	@Override
	public String toString() {
		String temp = "";
		for (int i = 0; i < names.length; i++) {
			temp = temp + names[i] + ", ";
		}
		return "NameCollection [names=" + temp + "]";
	}

}
