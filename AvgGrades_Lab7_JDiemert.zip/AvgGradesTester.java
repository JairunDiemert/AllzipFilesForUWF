import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
/**
The AvgGradesTester class tests the AvgGrades class. 
@author Jairun Diemert
@version 1.0

COP3022	Lab #: 7
File Name: AvgGradesTester.java
*/  
public class AvgGradesTester {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
        AvgGrades grades = new AvgGrades();
     
        boolean done = false;
        while (!done) 
        {
           try 
           {
              System.out.println("Please enter the file name: ");
              String filename = in.next();
              
              double average = grades.readFile(filename);
              System.out.printf("\nThe Average is: " + "%.2f" ,average);
              done = true;
           }
           catch (FileNotFoundException exception)
           {
              System.out.println("File not found.");
           }
           catch (BadDataException exception)
           {
              System.out.println("Bad data: " + exception.getMessage());
           }
           catch (IOException exception)
           {
              exception.printStackTrace();
           }

        }
        in.close();
	}

}
