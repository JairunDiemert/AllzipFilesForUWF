

import java.io.IOException;

/**
The BadDataException class reports bad input data. 
@author Jairun Diemert
@version 1.0

COP3022	Lab #: 7
File Name: BadDataException.java
*/  
public class BadDataException extends IOException {
private static final long serialVersionUID = 0;

   public BadDataException() {}
   public BadDataException(String message)
   {
      super(message);
   }
}
