import java.io.File;
import java.io.IOException;
import java.util.Scanner;
/**
The AvgGrades class reads doubles in a file and returns the average. 
@author Jairun Diemert
@version 1.0

COP3022	Lab #: 7
File Name: AvgGrades.java
*/  
public class AvgGrades {
	/**
	 * Array of grades
	 */
	private double[] grades;
	/**
	 * double to store average
	 */
	private double average;

	/**
	 * accesses a file and calls avgDat() returning an average
	 * @param filename name of file
	 * @return double average
	 * @throws IOException Input Output Exception
	 */
	public double readFile(String filename) throws IOException {
		File inFile = new File(filename);
		try {
			avgData(inFile);
			return average;
		} finally {

		}
	}

	/**
	 * returns the amount of variables are in file
	 * @param inFile file taken from read file
	 * @return returns an int value 
	 * @throws BadDataException throws user defined exception if variables are not double
	 * @throws IOException Input Output Exception
	 */
	public int countData(File inFile) throws BadDataException, IOException {
		Scanner in = new Scanner(inFile);
		int counter = 0;
		while (in.hasNext()) {
			if (!in.hasNextDouble()) {
				throw new BadDataException("Double value expected");
			}
			double temp = in.nextDouble();
			++counter;
		}
		in.close();
		return counter;
	}

	/**
	 * averages the data using array and countData function
	 * @param inFile file taken from read file
	 * @return average of all variables 
	 * @throws BadDataException throws user defined exception if variables are not double
	 * @throws IOException Input Output Exception
	 */
	public double avgData(File inFile) throws BadDataException, IOException {
		grades = new double[countData(inFile)];
		Scanner in = new Scanner(inFile);
		int i = 0;
		while (in.hasNext()) {
			if (!in.hasNextDouble()) {
				throw new BadDataException("Double value expected");
			}
			grades[i] = in.nextDouble();
			++i;
		}
		double sum = 0;
		for (double d : grades)
			sum = sum + d;
		average = sum / grades.length;

		in.close();
		return average;
	}

}
