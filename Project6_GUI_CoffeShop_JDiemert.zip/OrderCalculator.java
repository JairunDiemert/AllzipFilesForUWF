import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
/**
 * Represents JFrame 
 * COP3022: Intermediate Programming
 * Project 6
 * File Name: OrderCalculator.java
 * @author Jairun Diemert
 * @version 1.0
 */
@SuppressWarnings("serial")
public class OrderCalculator extends JFrame {
	
	/** The calculate. */
	private JButton calculate;
	
	/** The exit. */
	private JButton exit;
	
	/** The bread. */
	private JPanel bread;
	
	/** The meat cheese. */
	private JPanel meatCheese;
	
	/** The coffee. */
	private JPanel coffee;
	
	/** The button panel. */
	private JPanel buttonPanel;
	
	/** The welcome. */
	private JLabel welcome;
	
	/** The subtotal. */
	private double subtotal = 0.00;
	
	/** The tax rate. */
	private final double TAX_RATE = 0.075;
	
	/** The Constant WIDTH. */
	public static final int WIDTH = 500;
	
	/** The Constant HEIGHT. */
	public static final int HEIGHT = 400;

	/**
	 * Instantiates a new order calculator.
	 */
	public OrderCalculator() {
		super("Order Calculator");
		setSize(WIDTH, HEIGHT);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());

		welcome = new JLabel("Welcome to Johnny's Sandwich Shop");
		welcome.setHorizontalAlignment(JLabel.CENTER);
		welcome.setVerticalAlignment(JLabel.CENTER);
		add(welcome, BorderLayout.NORTH);

		Bread breadT = new Bread();
		bread = breadT.getBread();
		add(bread, BorderLayout.WEST);

		MEATandCHEESE meatCheeseT = new MEATandCHEESE();
		meatCheese = meatCheeseT.getMeatCheese();
		add(meatCheese, BorderLayout.CENTER);

		Coffee coffeeT = new Coffee();
		coffee = coffeeT.getCoffee();
		add(coffee, BorderLayout.EAST);

		buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout());

		calculate = new JButton("Calculate");
		calculate.addActionListener(new ButtonListener());
		buttonPanel.add(calculate);

		exit = new JButton("Exit");
		exit.addActionListener(new ButtonListener());
		buttonPanel.add(exit);

		add(buttonPanel, BorderLayout.SOUTH);

	}

	/**
	 * The listener interface for receiving button events.
	 * The class that is interested in processing a button
	 * event implements this interface, and the object created
	 * with that class is registered with a component using the
	 * component's <code>addButtonListener<code> method. When
	 * the button event occurs, that object's appropriate
	 * method is invoked.
	 *
	 * @see ButtonEvent
	 */
	private class ButtonListener implements ActionListener {

		/**
		 * Action performed.
		 *
		 * @param e the e
		 */
		public void actionPerformed(ActionEvent e) {
			String actionCommand = e.getActionCommand();

			if (actionCommand.equals("Calculate")) {
				if (Bread.white.isSelected()) {
					subtotal += Bread.WHITE;
				}
				if (Bread.wheat.isSelected()) {
					subtotal += Bread.WHEAT;
				}
				if (Coffee.regularCoffee.isSelected()) {
					subtotal += Coffee.REGULAR;
				}
				if (Coffee.decafCoffee.isSelected()) {
					subtotal += Coffee.DECAF;
				}
				if (Coffee.cappuccino.isSelected()) {
					subtotal += Coffee.CAPPUCCINO;
				}
				if (MEATandCHEESE.cheese.isSelected()) {
					subtotal += MEATandCHEESE.CHEESE;
				}
				if (MEATandCHEESE.roastBeef.isSelected()) {
					subtotal += MEATandCHEESE.ROAST_BEEF;
				}
				if (MEATandCHEESE.turkey.isSelected()) {
					subtotal += MEATandCHEESE.TURKEY;
				}
				if (MEATandCHEESE.ham.isSelected()) {
					subtotal += MEATandCHEESE.HAM;
				}
			} else if (actionCommand.equals("Exit")) {
				System.exit(0);
			} else {
				System.out.println("Unexpected error.");
			}
			JOptionPane.showMessageDialog(OrderCalculator.this,
					"Subtotal: $" + String.format("%.2f", subtotal) + "\nTax: $"
							+ String.format("%.2f", (subtotal * TAX_RATE)) + "\nTotal: $"
							+ String.format("%.2f", (subtotal + (subtotal * TAX_RATE))));
			subtotal = 0.0;
		}
	}
}
