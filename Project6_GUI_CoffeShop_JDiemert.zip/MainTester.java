
/**
 * Represents Main Tester
 * COP3022: Intermediate Programming
 * Project 6
 * File Name: MainTester.java
 * @author Jairun Diemert
 * @version 1.0
 */
public class MainTester {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		OrderCalculator gui = new OrderCalculator();
		gui.pack();
		gui.setVisible(true);
	}

}
