
import java.awt.GridLayout;
import javax.swing.ButtonGroup;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

/**
 * Represents JPanel
 * COP3022: Intermediate Programming
 * Project 6
 * File Name: Bread.java
 * @author Jairun Diemert
 * @version 1.0
 */
public class Bread {
	
	/** The bread. */
	private JPanel bread;
	
	/** The white. */
	public static JRadioButton white;
	
	/** The wheat. */
	public static JRadioButton wheat;
	
	/** The Constant WHITE. */
	public static final double WHITE = 1.00;
	
	/** The Constant WHEAT. */
	public static final double WHEAT = 1.50;

	/**
	 * Instantiates a new bread.
	 */
	public Bread() {

		white = new JRadioButton("White");
		white.setSelected(true);

		wheat = new JRadioButton("Wheat");

		ButtonGroup group = new ButtonGroup();
		group.add(white);
		group.add(wheat);

		bread = new JPanel();
		bread.setLayout(new GridLayout(2, 1));
		bread.add(white);
		bread.add(wheat);
		bread.setBorder(new TitledBorder(new EtchedBorder(), "Bread"));

	}

	/**
	 * Gets the bread.
	 *
	 * @return the bread
	 */
	public JPanel getBread() {
		return bread;
	}
}
