import java.awt.GridLayout;
import javax.swing.JPanel;
import javax.swing.JCheckBox;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

/**
 * Represents JPanel
 * COP3022: Intermediate Programming
 * Project 6
 * File Name: MEATandCHEESE.java
 * @author Jairun Diemert
 * @version 1.0
 */
public class MEATandCHEESE {
	
	/** The meat and cheese. */
	private JPanel meatAndCheese;
	
	/** The cheese. */
	public static JCheckBox cheese;
	
	/** The roast beef. */
	public static JCheckBox roastBeef;
	
	/** The turkey. */
	public static JCheckBox turkey;
	
	/** The ham. */
	public static JCheckBox ham;
	
	/** The Constant CHEESE. */
	public static final double CHEESE = 0.70;
	
	/** The Constant ROAST_BEEF. */
	public static final double ROAST_BEEF = 1.75;
	
	/** The Constant TURKEY. */
	public static final double TURKEY = 1.25;
	
	/** The Constant HAM. */
	public static final double HAM = 1.50;

	/**
	 * Instantiates a new MEA tand CHEESE.
	 */
	public MEATandCHEESE() {

		cheese = new JCheckBox("Cheese");
		cheese.setSelected(true);

		roastBeef = new JCheckBox("Roast Beef");

		turkey = new JCheckBox("Turkey");

		ham = new JCheckBox("Ham");

		meatAndCheese = new JPanel();
		meatAndCheese.setLayout(new GridLayout(4, 1));
		meatAndCheese.add(cheese);
		meatAndCheese.add(roastBeef);
		meatAndCheese.add(turkey);
		meatAndCheese.add(ham);
		meatAndCheese.setBorder(new TitledBorder(new EtchedBorder(), "Meat/Cheese"));
	}

	/**
	 * Gets the meat cheese.
	 *
	 * @return the meat cheese
	 */
	public JPanel getMeatCheese() {
		return meatAndCheese;
	}
}
