import java.awt.GridLayout;
import javax.swing.ButtonGroup;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

/**
 * Represents JPanel
 * COP3022: Intermediate Programming
 * Project 6
 * File Name: Coffee.java
 * @author Jairun Diemert
 * @version 1.0
 */
public class Coffee {

	/** The coffee. */
	private JPanel coffee;
	
	/** The none. */
	public static JRadioButton none;
	
	/** The regular coffee. */
	public static JRadioButton regularCoffee;
	
	/** The decaf coffee. */
	public static JRadioButton decafCoffee;
	
	/** The cappuccino. */
	public static JRadioButton cappuccino;
	
	/** The Constant NONE. */
	public static final double NONE = 0.00;
	
	/** The Constant REGULAR. */
	public static final double REGULAR = 1.75;
	
	/** The Constant DECAF. */
	public static final double DECAF = 1.65;
	
	/** The Constant CAPPUCCINO. */
	public static final double CAPPUCCINO = 3.00;

	/**
	 * Instantiates a new coffee.
	 */
	public Coffee() {

		none = new JRadioButton("None");
		none.setSelected(true);

		regularCoffee = new JRadioButton("Regular Coffee");

		decafCoffee = new JRadioButton("Decaf Coffee");

		cappuccino = new JRadioButton("Cappuccino");

		ButtonGroup group = new ButtonGroup();
		group.add(none);
		group.add(regularCoffee);
		group.add(decafCoffee);
		group.add(cappuccino);

		coffee = new JPanel();
		coffee.setLayout(new GridLayout(4, 1));
		coffee.add(none);
		coffee.add(regularCoffee);
		coffee.add(decafCoffee);
		coffee.add(cappuccino);
		coffee.setBorder(new TitledBorder(new EtchedBorder(), "Coffee"));

	}

	/**
	 * Gets the coffee.
	 *
	 * @return the coffee
	 */
	public JPanel getCoffee() {
		return coffee;
	}

}
