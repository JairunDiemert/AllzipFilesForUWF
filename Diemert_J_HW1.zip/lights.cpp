#include <iostream>
#include <cmath>
using namespace std;

int main() {

	int userInput = 0;
	int modInput = 1;
    	int count = 1;

	cout << "Please enter a number from 0-255 : " ;
        cin >> userInput ;
        cout << endl;
	
	while (count < 9) {
    
        modInput = userInput % 2;
        
		if (modInput == 1) { 
			cout << "Light " << count << " is turned on." ;
		}	
		else { 
			cout << "Light " << count << " is turned off.";
		}	        

	userInput /= 2;
	++count;
	cout << endl;
	
	}
	
	cout << endl;
	return 0;
}
