#include <iostream>
#include <cmath>
#include <complex>
using namespace std;

int main() {

	double aValue = 0; 
	double bValue = 0;
	double cValue = 0;
	double x1ValueA = 0;
	double x1ValueB = 0;
	double x2ValueA = 0;
	double x2ValueB = 0;
	double discrim = 0;

	cout << "Please input Value a of the Quadratic Equation: " ;
	cin >> aValue;
	cout << endl;
	cout << "Please input Value b of the Quadratic Equation: " ;
	cin >> bValue;
	cout << endl;
	cout << "Please input Value c of the Quadratic Equation: " ;
	cin >> cValue;
	cout << endl;
		
	discrim = ((bValue * bValue)-(4 * (aValue * cValue)));	
	
	if ( aValue == 0 ) {

        cout << "You are dividing by 0. Please run again and enter an ""a"" value not equaling 0." << endl << endl;
        }
	
	else if ( discrim < 0) {
		
		x1ValueA = (-(bValue)/(2 * (aValue))); 
		x1ValueB = (sqrt(-(discrim))/(2 * (aValue)));
		x2ValueA = (-(bValue)/(2 * (aValue)));
		x2ValueB = (sqrt(-(discrim))/(2 * (aValue)));
		
		if ( x1ValueB == 1 ) {
			 cout << "x = " << x1ValueA << " + i or ";
        		 cout << "x = " << x2ValueA << " - i" << endl << endl;
		}
		else {
			 cout << "x = " << x1ValueA << " + " << x1ValueB << "i or ";
        		 cout << "x = " << x2ValueA << " - " << x2ValueB << "i" << endl << endl;
		}	
	}
	else if ( discrim == 0 ) {
			
		x1ValueA = (-(bValue)/(2 * (aValue)));
                x2ValueA = (-(bValue)/(2 * (aValue)));
                
		cout << "x = " << x1ValueA << endl << endl;
	} 	
	else {
		
		x1ValueA = (-(bValue)/(2 * (aValue)));
                x1ValueB = (sqrt(discrim)/(2 * (aValue)));
                x2ValueA = (-(bValue)/(2 * (aValue)));
                x2ValueB = (sqrt(discrim)/(2 * (aValue)));
		cout << " x = " << x1ValueA + x1ValueB << " or " << x2ValueA - x2ValueB << endl << endl;
	}
		return 0;
}

