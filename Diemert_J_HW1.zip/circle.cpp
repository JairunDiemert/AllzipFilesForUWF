#include <iostream>
using namespace std;

int main() {
	
	const double PI = 3.14159265359;
	double A = 0.0;
	double r = 1.1;
	double c = 2.2;
	

	cout << "Please intput a the radius of your circle: " ;
	cin >> r ;
	cout << endl;

	A = PI * (r * r);
	c = 2 * (r * PI);
	
	cout << "The Area of your circle is " << A << " units squared." << endl;
	cout << "The circumference of your circle is " << c << " units." << endl;
 	
	return 0;
}

