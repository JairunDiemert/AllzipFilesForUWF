/**
The VacationTester class Tests the Vacation class and its subclasses
@author Jairun Diemert
@version 1.0

COP3022	Lab #: 5
File Name: VacationTester.java
*/
public class VacationTester {

	public static void main(String[] args) {
		AllInclusive vacation1 = new AllInclusive("Jamaica", 10000.00, "Sandals", 4, 7500.00);
		ALaCarte vacation2 = new ALaCarte("France", 20.00, "Holiday Inn", 120.00, "On no wings", 100.00, 1.00);

		Vacation[] Vacations = new Vacation[2];
		Vacations[0] = vacation1;
		Vacations[1] = vacation2;
		System.out.println(Vacations[0]);
		System.out.println(Vacations[1]);
		System.out.println("Test Polymorphic Call:" + Vacations[0].budgetBalance());
		System.out.println("Test Polymorphic Call:" + Vacations[1].budgetBalance());

	}

}
