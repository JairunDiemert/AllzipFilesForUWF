/**
The ALaCarte class handles A La Carte Vacation info
@author Jairun Diemert
@version 1.0

COP3022	Lab #: 5
File Name: ALaCarte.java
*/
public class ALaCarte extends Vacation {
	/**
	 * hotel name
	 */
	private String hotelName;
	/**
	 * room cost
	 */
	private double roomCost;
	/**
	 * name of airline 
	 */
	private String airline;
	/**
	 * cost of flight
	 */
	private double airfare;
	/**
	 * estimate of food cost
	 */
	private double meals; // estimated total meal expenses

	/**
	 * default constructor
	 */
	public ALaCarte() {
		super();
		hotelName = "Empty";
		roomCost = 0.0;
		airline = "Empty";
		airfare = 0.0;
		meals = 0.0;
	}

	/**
	 * parameterized construct 
	 * @param destination destination
	 * @param budget budget
	 * @param hotelName hotel name
	 * @param roomCost room cost
	 * @param airline airline 
	 * @param airfare airfare
	 * @param meals meal cost
	 */
	public ALaCarte(String destination, double budget, String hotelName, double roomCost, String airline,
			double airfare, double meals) {
		super(destination, budget);
		this.hotelName = hotelName;
		this.roomCost = roomCost;
		this.airline = airline;
		this.airfare = airfare;
		this.meals = meals;
	}

	/**
	 * return hotel name
	 * @return hotel name
	 */
	public String getHotelName() {
		return hotelName;
	}

	/**
	 * set hotel name
	 * @param hotelName hotel name
	 */
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	/**
	 * return room cost
	 * @return room cost
	 */
	public double getRoomCost() {
		return roomCost;
	}

	/**
	 * set room cost
	 * @param roomCost room cost 
	 */
	public void setRoomCost(double roomCost) {
		this.roomCost = roomCost;
	}

	/**
	 * get airline name
	 * @return airline name
	 */
	public String getAirline() {
		return airline;
	}

	/**
	 * set airline name
	 * @param airline airline name
	 */
	public void setAirline(String airline) {
		this.airline = airline;
	}

	/**
	 * return airfare
	 * @return airfare
	 */
	public double getAirfare() {
		return airfare;
	}

	/**
	 * set airfare
	 * @param airfare airfare 
	 */
	public void setAirfare(double airfare) {
		this.airfare = airfare;
	}

	/**
	 * return meal cost
	 * @return meal cost 
	 */
	public double getMeals() {
		return meals;
	}

	/**
	 * set meal cost 
	 * @param meals cost
	 */
	public void setMeals(double meals) {
		this.meals = meals;
	}

	/**
	 * calculate budget balance 
	 */
	@Override
	public double budgetBalance() {
		double temp;
		temp = super.getBudget() - (getRoomCost() + getAirfare() + getMeals());
		return temp;
	}

	/**
	 *toString to return content of class object 
	 */
	@Override
	public String toString() {
		return " Vacation Info\n~~~~~~~~~~~~~~~~~\n" + super.toString() + "HotelName= " + getHotelName() + "\nRoomCost= " + getRoomCost() + "\nAirline= "
				+ getAirline() + "\nAirfare= " + getAirfare() + "\ngetMeals= " + getMeals() + "\nbudgetBalance= "
				+ budgetBalance() + "\n\n";
	}

	

}
