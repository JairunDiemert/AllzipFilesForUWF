/**
The AllInclusive class handles All inclusive vacation info
@author Jairun Diemert
@version 1.0

COP3022	Lab #: 5
File Name: AllInclusive.java
*/
public class AllInclusive extends Vacation {
	/**
	 * Name of vacation institution 
	 */
	private String brand;
	/**
	 * rating of institution
	 */
	private int rating;
	/**
	 * price to stay at institution 
	 */
	double price;

	/**
	 * default constructor
	 */
	public AllInclusive() {
		super();
		brand = "Empty";
		rating = -1;
		price = 0.0;
	}

	/**
	 * parameterized constructor
	 * @param destination vacation destination 
	 * @param budget vacation budget
	 * @param brand Name of vacation institution
	 * @param rating rating of institution
	 * @param price price to stay at institution
	 */
	public AllInclusive(String destination, double budget, String brand, int rating, double price) {
		super(destination, budget);
		this.brand = brand;
		this.rating = rating;
		this.price = price;
	}

	/**
	 * return institution name
	 * @return institution name
	 */
	public String getBrand() {
		return brand;
	}

	/**
	 * set institution name from parameter 
	 * @param brand institution name
	 */
	public void setBrand(String brand) {
		this.brand = brand;
	}

	/**
	 * return institution rating
	 * @return institution rating 
	 */
	public int getRating() {
		return rating;
	}

	/**
	 * set institution rating
	 * @param rating institution rating
	 */
	public void setRating(int rating) {
		this.rating = rating;
	}

	/**
	 * return price
	 * @return price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * set price
	 * @param price price
	 */
	public void setPrice(double price) {
		this.price = price;
	}

	/**
	 *Calculate and return budget balance 
	 */
	@Override
	public double budgetBalance() {
		double temp;
		temp = super.getBudget() - getPrice();
		return temp;
	}

	/**
	 *toString to print content of class object 
	 */
	@Override
	public String toString() {
		return " Vacation Info\n~~~~~~~~~~~~~~~~~\n" + super.toString() + "Brand= " + getBrand() + "\nRating= " + getRating() + "\nPrice= " + getPrice()
				+ "\nbudgetBalance= " + budgetBalance() + "\n\n";
	}

}
