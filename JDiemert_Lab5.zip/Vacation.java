/**
The Vacation class handles vacation info
@author Jairun Diemert
@version 1.0

COP3022	Lab #: 5
File Name: Vacation.java
*/
public abstract class Vacation {
	/**
	 * Name of destination
	 */
	private String destination;
	/**
	 * Vacation budget
	 */
	private double budget;

	/**
	 * Default Constructor 
	 */
	public Vacation() {
		destination = "Empty";
		budget = 0.0;
	}

	/**
	 * Parameterized constructor
	 * @param destination vacation destination 
	 * @param budget vacation budget
	 */
	public Vacation(String destination, double budget) {
		this.destination = destination;
		this.budget = budget;
	}

	/**
	 * returns the vacation destination
	 * @return vacation destination
	 */
	public String getDestination() {
		return destination;
	}

	/**
	 * set destination to parameter 
	 * @param destination vacation destination
	 */
	public void setDestination(String destination) {
		this.destination = destination;
	}

	/**
	 * returns vacation budget 
	 * @return vacation budget
	 */
	public double getBudget() {
		return budget;
	}

	/**
	 * set budget to parameter
	 * @param budget vacation budget
	 */
	public void setBudget(double budget) {
		this.budget = budget;
	}

	/**
	 * Abstract method to be used to calculate the budget balance
	 * @return budget balance;
	 */
	public abstract double budgetBalance();

	/**
	 * toString to print contents of class variable 
	 */
	@Override
	public String toString() {
		return "Destination= " + getDestination() + "\nBudget= " + getBudget() + "\n";
	}

}
