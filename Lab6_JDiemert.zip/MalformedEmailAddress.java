/**
 * The MalformedEmailAddress class handles email exceptions info
 * 
 * @author Jairun Diemert
 * @version 1.0
 * 
 * COP3022 Lab #: 6 
 * File Name: MalformedEmailAddress.java
 */
public class MalformedEmailAddress extends Exception {
	public MalformedEmailAddress(String s) 
    { 
        super(s); 
    } 
}
