import java.util.Scanner;
/**
 * The UserTester class tests user info
 * 
 * @author Jairun Diemert
 * @version 1.0
 * 
 * COP3022 Lab #: 6 
 * File Name: UserTester.java
 */
public class UserTest {

	public static void main(String[] args) {
		String userInfo = "Joe,10,100,j10oe,joee@mail.com,1,2,3,4@";
		Scanner scnr = new Scanner(userInfo).useDelimiter(",");
		User user = new User();
		System.out.println("Default info[ " + user + " ]");

		String tempName = scnr.next();
		int tempAge = scnr.nextInt();
		String tempSalary = scnr.next();
		String tempHackerName = scnr.next();
		String tempEmail = scnr.next();
		Boolean bool = false;

		System.out.print("\nSet/Get-Name :");
		user.setName("ABCD");
		System.out.println(user.getName());

		System.out.print("Set/Get-Age :");
		user.setAge(100);
		System.out.println(user.getAge());

		System.out.print("Set/Get-Salary :");
		user.setSalary("30000B");

		System.out.print("Set/Get-Salary :");
		user.setSalary("30000");
		System.out.println(user.getSalary());

		System.out.print("Set/Get-HackerName :");
		user.setHackerName();
		System.out.println(user.getHackerName());

		do {
			String temp = scnr.next();
			System.out.print("Enter Email: " + temp + "   ");
			if (user.setEmail(temp)) {
				bool = true;
			};			
		} while (!bool);

		scnr.close();
	}

}
