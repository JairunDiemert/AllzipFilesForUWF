/**
 * The User class handles user info
 * 
 * @author Jairun Diemert
 * @version 1.0
 * 
 * COP3022 Lab #: 6 
 * File Name: User.java
 */
public class User {
	/**
	 * name of user
	 */
	private String name;
	/**
	 * age of user
	 */
	private int age;
	/**
	 * salary of user
	 */
	private int salary;
	/**
	 * randomized hacker name
	 */
	private String hackerName;
	/**
	 * email address 
	 */
	private String email;

	/**
	 * Default constructor 
	 */
	public User() {
		setName("empty");
		setAge(-1);
		setSalary("-1");
		setHackerName();
		setEmail("empty@");
	}

	/**
	 * returns user name
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * set user name
	 * @param name name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * return age of user
	 * @return age
	 */
	public int getAge() {
		return age;
	}

	/**
	 * set user age
	 * @param age age
	 */
	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * return salary of user
	 * @return salary
	 */
	public int getSalary() {
		return salary;
	}

	/**
	 * sets Salary if formated correctly
	 * @param salary salary
	 * @return true or false 
	 */
	public boolean setSalary(String salary) {
		try {
			this.salary = Integer.parseInt(salary);
			return true;
		} catch (NumberFormatException e) {
			System.out.println("NumberFormatException thrown");
			return false;
		}
	}

	/**
	 * return hacker name
	 * @return hacker name
	 */
	public String getHackerName() {
		return hackerName;
	}

	/**
	 * set Hacker name using sudo randomization. 
	 */
	public void setHackerName() {
		char[] name = new char[getName().length()];
		for (int i = 0; i < getName().length(); i++) {
		name[i] = (char)(getName().charAt(i) + getAge());
		}
		String temp = new String(name);
		this.hackerName = temp;
	}

	/**
	 * return email
	 * @return email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * set email if it contains an @ symbol
	 * @param email email
	 * @return true or false
	 */
	public boolean setEmail(String email) {

		try {
			if (email.contains("@")) {
				this.email = email;
				return true;
			} else {
				throw new MalformedEmailAddress("Invalid Email. Please try again.");
			}
		} catch (MalformedEmailAddress e) {
			System.out.println(e.getMessage());
			return false;
		}
	}

	/**
	 *format variables to string for printing
	 */
	@Override
	public String toString() {
		return "Name: " + getName() + ", Age: " + getAge() + ", Salary: " + getSalary() + ", HackerName: "
				+ getHackerName() + ", Email: " + getEmail();
	}

}
