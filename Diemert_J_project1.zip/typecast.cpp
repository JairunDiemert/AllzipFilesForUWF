#include <iostream>
using namespace std;

int main () {

	double userInput1 = 0.0;
	int modInput = 1;  
	double userOutput1 = 2;

	cout << "Please input a float number with more than three digits after the decimal point: ";
	cin >> userInput1;

	modInput = userInput1 * 100;
	userOutput1 = modInput *.01;
 
	cout << "The truncated result of " << userInput1 << " is " << userOutput1 << "." << endl;	


	return 0;
}
