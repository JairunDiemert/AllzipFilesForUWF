#include <iostream>
using namespace std;

int main () {
	
	int a = 11;
	int b = 3;
	int c = 100;
	int expTree = ((a % b) != 2) && ((a * 10) < c);
	
	cout << "The result is " << expTree << "." << endl;
	   
	return 0;
}
