/**
The ContactList class handles passwords
@author Jairun Diemert
@version 1.0

COP3022	Lab #: 3
File Name: ContactList.java
*/  
public class ContactList {
	/**
	 * Integer value for array size
	 */
	private int maxNumberElements = 10;
	/**
	 * Array of Class objects 
	 */
	private ContactListEntry[] entry;
	/**
	 * Integer counter value for Array entry size
	 */
	private int numOfEntries;

	/**
	 * Default constructor 
	 */
	public ContactList() {
		this.maxNumberElements = 10;
		this.entry = new ContactListEntry[maxNumberElements];
		this.numOfEntries = 0;
	}

	/**Add function that adds a new element to the array
	 * @param entryNum class object 
	 */
	public void add(ContactListEntry entryNum) {
		if (numOfEntries >= entry.length) {
			System.out.println("Error: Adding to a full array.");
			System.exit(0);
		} else {
			entry[numOfEntries] = entryNum;
			numOfEntries++;
		}
	}

	/**Print function to print all the elements in the array
	 * @return formated output of each array element 
	 */
	public String print() {
		if (numOfEntries >= entry.length) {
			String elements = "Error: Adding to a full array.";
			return elements;
		} else {
			String elements = "The Array elements are:\n ";
			for (int i = 0; i < numOfEntries; i++) {
				elements += entry[i] + "\n ";
			}
			return elements;
		}
	}
}
