/**
The ContactListEntry class handles passwords
@author Jairun Diemert
@version 1.0

COP3022	Lab #: 3
File Name: ContactListEntry.java
*/  
public class ContactListEntry {
	/**
	 * String holds contact name
	 */
	private String name;
	/**
	 * String holds contact PhoneNumber
	 */
	private String phoneNumber;
	/**
	 * String holds contact email
	 */
	private String emailAddress;

	/**
	 * Default constructor
	 */
	public ContactListEntry() {
		this.name = "nameEmpty";
		this.phoneNumber = "phoneNumberEmpty";
		this.emailAddress = "emailAddressEmpty";

	}

	/**Parameterized constructor
	 * @param name string name
	 * @param phoneNumber string PNumber
	 * @param emailAddress string email
	 */
	public ContactListEntry(String name, String phoneNumber, String emailAddress) {
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.emailAddress = emailAddress;
	}

	/**return contact name
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**Set name
	 * @param name name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**return contact Phone Number
	 * @return Phone Number
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**Set phone Number 
	 * @param phoneNumber phoneNumber
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**return emailAddress
	 * @return email
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**Set emailAddress 
	 * @param emailAddress emailAddress
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 *returns a string of contents of ContactListEntry instead of reference location
	 */
	@Override
	public String toString() {
		return "ContactListEntry [name= " + name + ", phoneNumber= " + phoneNumber + ", emailAddress= " + emailAddress
				+ "]";
	}

}
