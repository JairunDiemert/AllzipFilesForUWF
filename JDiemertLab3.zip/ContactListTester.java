/**
The ContactListTester class handles passwords
@author Jairun Diemert
@version 1.0

COP3022	Lab #: 3
File Name: ContactListTester.java
*/  
public class ContactListTester {

	public static void main(String[] args) {
		ContactList list1 = new ContactList();
		ContactListEntry entry1 = new ContactListEntry("entry1Name", "entry1Phone", "entry1Email");
		ContactListEntry entry2 = new ContactListEntry("entry2Name", "entry2Phone", "entry2Email");
		ContactListEntry entry3 = new ContactListEntry("entry3Name", "entry3Phone", "entry3Email");

		list1.add(entry1);
		list1.add(entry2);
		list1.add(entry3);
		
        System.out.println(list1.print());
        
        ContactListEntry entry4 = new ContactListEntry("entry4Name", "entry4Phone", "entry4Email");
        list1.add(entry4);
        
        System.out.println(list1.print());

	}

}
