import java.util.Scanner;

public class EncryptionTester {

	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		int key = -1;
		String password = "";
		Boolean exit = true;
		Boolean run = true;

		while (run) {
			System.out.println("Would you like to continue? (1 for yes & 0 for no) :");
			if (scnr.nextInt() == 1) {

				while (exit) {
					System.out.println("Enter a password of at least 8 characters:");
					password = scnr.next();
					if (password.length() <= 7) {
						System.out.println("The password must be at least 8 characters long, "
								+ "your password is only " + password.length() + " characters long.");
					} else {
						exit = false;
					}
				}
				exit = true;
				while (exit) {
					System.out.println("Enter a encryption key from 1-10:");
					key = scnr.nextInt();
					if (key <= 0 || key >= 11) {
						System.out.println("The key must be between 1 and 10, the number you entered is " + key + ".");
					} else {
						exit = false;
					}
				}
				exit = true;
				
				Encryption defaultUser = new Encryption();
				Encryption inputUser = new Encryption(key, password);
				System.out.println(inputUser.toString());
				System.out.println("Enter password to test:");
				inputUser.isValidPassword(scnr.next());
				System.out.println("Enter new key:");
				inputUser.setKey(scnr.nextInt());
			} else {
				System.out.println("Good Bye");
				run = false;
			}

		}
	}
}
