/**
The Encryption class handles passwords
@author Jairun Diemert
@version 1.0

COP3022	Project #: 1
File Name: Encryption.java
*/  
public class Encryption {
	/**
	 * This stores the encryption key
	 */
	private int key;
	/**
	 * This stores the password after being encrypted
	 */
	private String encryptedPassword;

	/**
	 * This is the default constructor 
	 */
	public Encryption() {
		this.setKey(0);
		this.setEncryptedPassword("Unknown");
	}

	/**
	 * This is the constructor that takes in user key and password
	 * @param key encryption key
	 * @param encryptedPassword encrypted password
	 */
	public Encryption(int key, String encryptedPassword) {
		this.key = key;
		this.encryptedPassword = encrypt(encryptedPassword);
	}

	/**
	 * This returns the stored encrypted password
	 * @return the encryptedPassword
	 */
	public String getEncryptedPassword() {
		return encryptedPassword;
	}
	

	/**
	 * This can set the stored password (only used by default constructor)
	 * @param encryptedPassword the encryptedPassword
	 */
	private void setEncryptedPassword(String encryptedPassword) {
		this.encryptedPassword = encryptedPassword;
	}

	/**
	 * This can set the key and the password 
	 * @param key the key
	 * @param encryptedPassword the encryptedPassword
	 */
	public void setPassword(int key, String encryptedPassword) {
		this.key = key;
		this.encryptedPassword = encrypt(encryptedPassword);
	}

	/**This can set the key
	 * @param key the key
	 */
	public void setKey(int key) {
		this.key = key;
	}

	/**This can return the key
	 * @return the key
	 */
	public int getKey() {
		return key;
	}

	/**This algorithm encrypts the entered password
	 * @param password the encryptedPassword
	 * @return the encryptedPassword
	 */
	public String encrypt(String password) {
		String encryptedPassword;
		char[] temp = new char[25];
		for (int i = 0; i < password.length(); i++) {
			char c = password.charAt(i);
			if ((c + getKey()) >= 123) {
				c = (char) (c - 89);
				temp[i] = c;

			} else {
				c = (char) (c + getKey());
				temp[i] = c;
			}
		}
		encryptedPassword = new String(temp);
		return encryptedPassword;
	}

	/**This can verify if you have the correct password
	 * @param password the encryptedPassword
	 * @return true or false
	 */
	public Boolean isValidPassword(String password) {
		if (encrypt(password).equals(getEncryptedPassword())) {
			System.out.println("Password Match = True");
			return true;
		} else {
			System.out.println("Password Match = False");
			return false;
		}
	}

	/**
	 *This returns the values of key and password
	 */
	@Override
	public String toString() {
		return "The encrypted password is: " + getEncryptedPassword() +
				"\nThe key used to generate this password is: " + getKey() + ".";
	}
	
}