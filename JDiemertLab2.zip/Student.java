/**
 * Student can be created, and details added.
 * 
 * @author Jairun Diemert
 * @version 1.0
 * 
 *          COP3022 Lab #: 2 File Name: Student.java
 */
public class Student {
	/**
	 * Name of student
	 */
	private String name;
	/**
	 * Sum of quiz scores
	 */
	private double totalQuizScore;
	/**
	 * Number of quizzes
	 */
	private int numQuizesTaken;

	/**
	 * Constructs a Student object with default values for instance fields
	 */
	public Student() {
		this.name = "nameUnknown";
		this.totalQuizScore = 0;
		this.numQuizesTaken = 0;
	}

	/**
	 * Constructs a door object
	 * 
	 * @param name the name of the student
	 */
	public Student(String name) {
		this.name = name;
		this.totalQuizScore = 0;
		this.numQuizesTaken = 0;
	}

	/**
	 * Returns the name of the student
	 * @return name of student
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name of the student to the parameter 
	 * @param name of student
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Returns sum of all entered quiz scores
	 * @return sum of all entered quiz scores
	 */
	public double getTotalQuizScore() {
		return totalQuizScore;
	}

	/**Returns number of quizzes entered by student
	 * @return number of quizzes entered by student
	 */
	public int getNumQuizesTaken() {
		return numQuizesTaken;
	}

	/**Adds quiz score from the parameter to totalQuizScore
	 * @param quizScore current quiz grade
	 */
	public void addQuiz(double quizScore) {
		System.out.println();
		if (quizScore >= 0 && quizScore <= 100) {
			this.totalQuizScore = this.totalQuizScore + quizScore;
			++numQuizesTaken;
		} else {
			System.out.println("Quiz score must be from 0 to 100");
		}

	}

	/**Returns the average quiz score
	 * @return the average quiz score
	 */
	public double getAverageScore() {
		double averageQuizScore;
		averageQuizScore = getTotalQuizScore() / getNumQuizesTaken();
		return averageQuizScore;
	}

}
