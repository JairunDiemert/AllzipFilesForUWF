/**
A class to test the Student class.
@author Jairun Diemert
@version 1.0

COP3022	Lab #: 2
File Name: StudentTester.java
*/  
import java.util.Scanner;

public class StudentTester {

	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		System.out.println("Enter name: ");
		Student student1 = new Student(scnr.nextLine());
		Boolean exit = true;
		while (exit) {
			System.out.println("Enter quiz score: ");
			student1.addQuiz(scnr.nextDouble());
			System.out.println("Finished? (enter '0' for yes, or '1' for no");
			if (scnr.nextInt() != 1) {
				exit = false;
			}
		}
		System.out.println("Name: " + student1.getName() + "\nTotal Score: ");
		System.out.printf("%.2f", student1.getTotalQuizScore());
		System.out.println("\nAverage Score: ");
		System.out.printf("%.2f", student1.getAverageScore());
		Student student2 = new Student();
		student2.setName("Name Test");
		System.out.println("\n\nName2: " + student2.getName());
	}
}
