import java.util.ArrayList;

/**
 * The Class MyMathClass.
 * 
 * COP3022 Lab #: 9 
 * File Name: MyMathClass.java
 * @author Jairun Diemert
 * @version 1.0
 * @param <T> the generic type
 */
public class MyMathClass<T extends Number> {

	/**
	 * Average.
	 *
	 * @param list the list
	 * @return the double
	 */
	public Double average(ArrayList<T> list) {
		Double average = 0.0;
		for (T temp : list) {
			average = average + temp.doubleValue();
		}
		average = average / list.size();
		return average;
	}

	/**
	 * Standard deviation.
	 *
	 * @param list the list
	 * @return the double
	 */
	public Double standardDeviation(ArrayList<T> list) {
		Double stD = 0.0;
		for (T temp : list) {
			stD = stD + ((temp.doubleValue() - average(list)) * (temp.doubleValue() - average(list)));
			System.out.println("  " + String.format("%.2f", temp.doubleValue()) + " - "
					+ String.format("%.2f", average(list)) + " = sqrd("
					+ String.format("%.2f", (temp.doubleValue() - average(list))) + ") = " + String.format("%.2f",
							(((temp.doubleValue() - average(list)) * (temp.doubleValue() - average(list))))));
		}
		System.out.print(" +_______________________________________________\n  " + String.format("%.2f", stD) + " / " + list.size() + " = ");
		stD = stD / list.size();
		System.out.print("sqrt(" + String.format("%.2f", stD) + ") " + "\n\n = ");
		System.out.print("Standard Deviation: ");
		stD = Math.sqrt(stD);
		return stD;
	}
}
