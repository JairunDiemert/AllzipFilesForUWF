import java.util.ArrayList;

/**
 * The Class MyMathClassTester.
 * 
 * COP3022 Lab #: 9 
 * File Name: MyMathClassTester.java
 * @author Jairun Diemert
 * @version 1.0
 * @param <T> the generic type
 */
public class MyMathClassTester {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		ArrayList<Integer> myIntegers = new ArrayList<Integer>();
		myIntegers.add(26);
		myIntegers.add(801);
		myIntegers.add(669);

		ArrayList<Double> myDoubles = new ArrayList<Double>();
		myDoubles.add(26.33);
		myDoubles.add(801.689);
		myDoubles.add(.669);

		ArrayList<Long> myLongs = new ArrayList<Long>();
		myLongs.add(2633L);
		myLongs.add(801689L);
		myLongs.add(669L);

		MyMathClass<Integer> mathInteger = new MyMathClass<Integer>();
		MyMathClass<Double> mathDouble = new MyMathClass<Double>();
		MyMathClass<Long> mathLong = new MyMathClass<Long>();

		System.out
				.println("   Integer Standard Deviation break down\n________________________________________________");
		System.out.println(
				String.format("%.2f", mathInteger.standardDeviation(myIntegers)) + "\n_________________________________________________\n\n");

		System.out.println("   Double Standard Deviation break down\n________________________________________________");
		System.out.println(
				String.format("%.2f", mathDouble.standardDeviation(myDoubles)) + "\n_________________________________________________\n\n");

		System.out.println("   Long Standard Deviation break down\n________________________________________________");
		System.out.println(
				String.format("%.2f", mathLong.standardDeviation(myLongs)) + "\n_________________________________________________\n\n");

		// 5. What happens if you create a MyMathClass object with a String type
		// parameter?
		// MyMathClass<String> mathString = new MyMathClass<String>();
		// Bound mismatch: The type String is not a valid substitute for the bounded
		// parameter <T extends Number> of the type MyMathClass<T>

	}

}
