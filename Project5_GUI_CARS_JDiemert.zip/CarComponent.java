package Mine;

/**
 * Draws Car objects 
 * COP3022: Intermidiate Programming
 * Project 5
 * File Name: CarComponent.java
 * @author Jairun Diemert
 * @version 1.0
 */
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import javax.swing.JComponent;
import java.util.Random;

/**
 * The Class CarComponent.
 */
public class CarComponent extends JComponent {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The cars. */
	private ArrayList<Car> cars;

	/**
	 * Instantiates a new car component.
	 */
	public CarComponent() {

		cars = new ArrayList<Car>();
	}

	/**
	 * Adds the.
	 *
	 * @param car the car
	 */
	public void add(Car car) {
		cars.add(car);
	}

	/**
	 * Move cars.
	 */
	public void moveCars() {
		Random rand = new Random();
		int carBoundry = getWidth() - 60;
		for (Car car : cars) {
			if ((car.getXLeft() < carBoundry) && (car.getForward()))
				car.translate(rand.nextInt(10) + 1, 0);
			else if (car.getXLeft() > 0) {
				car.translate(-1 * (rand.nextInt(10) + 1), 0);
				car.setForward(false);
			} else
				car.setForward(true);

		}
	}

	/**
	 * Move cars.
	 *
	 * @param movement the movement
	 */
	public void moveCars(int movement) {
		Random rand = new Random();
		int carBoundry = getWidth() - 60;
		for (Car car : cars) {
			if ((car.getXLeft() < carBoundry) && (car.getForward()))
				car.translate(rand.nextInt(10) + movement, 0);
			else if (car.getXLeft() > 0) {
				car.translate(-1 * (rand.nextInt(10) + movement), 0);
				car.setForward(false);
			} else
				car.setForward(true);

		}
	}

	/**
	 * Paint component.
	 *
	 * @param g the g
	 */
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;

		for (Car car : cars)
			car.draw(g2);
	}
}
