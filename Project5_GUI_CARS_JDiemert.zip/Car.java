package Mine;

/**
 * Represents a car to be drawn 
 * COP3022: Intermidiate Programming
 * Project 5 
 * File Name: Car.java
 * @author Jairun Diemert
 * @version 1.0
 */
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;

/**
 * The Class Car.
 */
public class Car {

	/** The x left. */
	private int xLeft;

	/** The y top. */
	private int yTop;

	/** The forward. */
	private boolean forward;

	/**
	 * Instantiates a new car.
	 *
	 * @param x the x
	 * @param y the y
	 */
	public Car(int x, int y) {
		xLeft = x;
		yTop = y;
		forward = true;
	}

	/**
	 * Translate.
	 *
	 * @param dx the dx
	 * @param dy the dy
	 */
	public void translate(int dx, int dy) {
		xLeft = xLeft + dx;
		yTop = yTop + dy;
	}

	/**
	 * Draw.
	 *
	 * @param g2 the g 2
	 */
	public void draw(Graphics2D g2) {
		Rectangle body = new Rectangle(xLeft, yTop + 10, 60, 20);
		Ellipse2D.Double frontTire = new Ellipse2D.Double(xLeft + 5, yTop + 17, 15, 15);
		Ellipse2D.Double frontRim = new Ellipse2D.Double(xLeft + 7, yTop + 20, 10, 10);
		Ellipse2D.Double rearTire = new Ellipse2D.Double(xLeft + 40, yTop + 17, 15, 15);
		Ellipse2D.Double rearRim = new Ellipse2D.Double(xLeft + 42, yTop + 20, 10, 10);

		// The bottom of the front windshield
		Point2D.Double r1 = new Point2D.Double(xLeft + 10, yTop + 10);
		// The front of the roof
		Point2D.Double r2 = new Point2D.Double(xLeft + 20, yTop);
		// The rear of the roof
		Point2D.Double r3 = new Point2D.Double(xLeft + 40, yTop);
		// The bottom of the rear windshield
		Point2D.Double r4 = new Point2D.Double(xLeft + 50, yTop + 10);

		Line2D.Double frontWindshield = new Line2D.Double(r1, r2);
		Line2D.Double roofTop = new Line2D.Double(r2, r3);
		Line2D.Double rearWindshield = new Line2D.Double(r3, r4);

		g2.draw(body);
		g2.draw(frontTire);
		g2.draw(frontRim);
		g2.draw(rearTire);
		g2.draw(rearRim);
		g2.draw(frontWindshield);
		g2.draw(roofTop);
		g2.draw(rearWindshield);
	}

	/**
	 * Gets the x left.
	 *
	 * @return the x left
	 */
	public int getXLeft() {
		return xLeft;
	}

	/**
	 * Gets the y top.
	 *
	 * @return the y top
	 */
	public int getYTop() {
		return yTop;
	}

	/**
	 * Gets the forward.
	 *
	 * @return the forward
	 */
	public boolean getForward() {
		return forward;
	}

	/**
	 * Sets the forward.
	 *
	 * @param direction the new forward
	 */
	public void setForward(boolean direction) {
		forward = direction;
	}

}