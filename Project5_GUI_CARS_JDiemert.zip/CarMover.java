package Mine;

/**
 * Allows draw cars to move on a JFrame
 * COP3022: Intermidiate Programming
 * Project 5 
 * File Name: CarMover.java
 * @author Jairun Diemert
 * @version 1.0
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 * The Class CarMover.
 */
public class CarMover {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {

		String movement = JOptionPane.showInputDialog("Enter movement increment");
		int dMovement = Integer.parseInt(movement);
		String delay = JOptionPane.showInputDialog("Enter time delay");
		int dDelay = Integer.parseInt(delay);

		JFrame frame = new JFrame();
		frame.setSize(300, 400);
		frame.setTitle("Race");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		CarComponent component = new CarComponent();
		Car car1 = new Car(0, 0);
		Car car2 = new Car(0, frame.getHeight() / 2);
		Car car3 = new Car(0, frame.getHeight() / 3);
		Car car4 = new Car(0, frame.getHeight() / 6);
		component.add(car1);
		component.add(car2);
		component.add(car3);
		component.add(car4);

		frame.add(component);
		frame.setVisible(true);

		class TimerListener implements ActionListener {
			public void actionPerformed(ActionEvent event) {
				component.moveCars(dMovement);
				component.repaint();
			}
		}

		ActionListener listener = new TimerListener();

		Timer t = new Timer(dDelay, listener);
		t.start();
	}
}
