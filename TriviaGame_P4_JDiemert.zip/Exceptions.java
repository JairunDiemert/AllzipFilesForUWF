/**The Exceptions class catches exceptions
 * 
 * @author Jairun Diemert
 * @version 1.0
 * 
 * COP3022 Project #: 4 
 * File Name: Exceptions.java
 */
public class Exceptions extends Exception {

	/**sets the serialVersionUID
	 * 
	 */
	private static final long serialVersionUID = 0;

	/**default constructor 
	 * 
	 */
	public Exceptions() {
	}

	/**Constructor with message
	 * @param arg0 String
	 */
	public Exceptions(String arg0) {
		super(arg0);
	}

}
