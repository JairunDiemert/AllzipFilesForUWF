import java.util.Random;

/**The TriviaGame class provides random questions and checks answers
 * 
 * @author Jairun Diemert
 * @version 1.0
 * 
 * COP3022 Project #: 4 
 * File Name: TriviaGame.java
 */
public class TriviaGame extends Administrator {
	
	/**storage for random question
	 * 
	 */
	private String question = "";
	
	/**index for question
	 * 
	 */
	private int index = -1;

	/**sets the index for a random question
	 * @return index
	 */
	private int randomize() {
		Random random = new Random();
		index = random.nextInt(getqArray().length - 1);
		try {
			if (!(index > -1 && index < getqArray().length)) {
				throw new Exceptions("Random number produced larger than array length");
			}
		} catch (Exception e) {
			e.getStackTrace();
		}
		return index;
	}

	/**return index
	 * @return index
	 */
	public int getIndex() {
		return index;
	}

	/**prints out a random question
	 * @return random question
	 */
	public String getRandomQuestion() {
		question = getqArrayVar(randomize()).getQuestion();
		System.out.println("\nQuestion " + index);
		return question;
	}

	/**checks user input answer
	 * @param answer input answer 
	 * @return boolean true or false
	 */
	public Boolean checkAnswer(String answer) {
		boolean result = false;
		if (!(getqArrayVar(index).getAnswer().equalsIgnoreCase(answer))) {
			System.out.println("Wrong. The correct answer is " + getqArrayVar(index).getAnswer());
		} else {
			System.out.println("That is correct!");
			result = true;
		}
		return result;
	}

}
