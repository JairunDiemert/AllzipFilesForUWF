/**The Questions class stores individual question details
 * 
 * @author Jairun Diemert
 * @version 1.0
 * 
 * COP3022 Project #: 4 
 * File Name: Questions.java
 */
public class Questions {
	
	/**marked for (D)eletion or (A)cceptable question
	 * 
	 */
	private String status;
	
	/**Question string
	 * 
	 */
	private String question;
	
	/**answer for question
	 * 
	 */
	private String answer;
	
	/**question point value
	 * 
	 */
	private String value;
	
	/**question number in list
	 * 
	 */
	private String questionID;

	/**default constructor
	 * 
	 */
	public Questions() {
		setStatus("A");
		setQuestion("null");
		setAnswer("null");
		setValue("0");
		setQuestionID("0");
	}

	/**Parameterized constructor
	 * @param status marked for deletion or not
	 * @param ID number in question list
	 * @param question question string
	 * @param answer answer to question
	 * @param value question point value
	 */
	public Questions(String status, String ID, String question, String answer, String value) {
		setStatus(status);
		setQuestionID(ID);
		setQuestion(question);
		setAnswer(answer);
		setValue(value);
	}

	/**returns questions status
	 * @return status 
	 */
	private String getStatus() {
		return status;
	}

	/**set status
	 * @param status status 
	 */
	private void setStatus(String status) {
		this.status = status;
	}

	/**returns question
	 * @return
	 */
	public String getQuestion() {
		return question;
	}

	/**set question
	 * @param question question
	 */
	private void setQuestion(String question) {
		this.question = question;
	}

	/**return answer to question
	 * @return
	 */
	public String getAnswer() {
		return answer;
	}

	/**set answer
	 * @param answer answer
	 */
	private void setAnswer(String answer) {
		this.answer = answer;
	}

	/**returns value
	 * @return value
	 */
	public String getValue() {
		return value;
	}

	/**set value
	 * @param value value
	 */
	private void setValue(String value) {
		this.value = value;
	}

	/**returns question ID
	 * @return question ID
	 */
	public String getQuestionID() {
		return questionID;
	}

	/**set question ID
	 * @param questionID question ID
	 */
	public void setQuestionID(String questionID) {
		this.questionID = questionID;
	}

	/**returns question elements
	 *
	 */
	@Override
	public String toString() {
		return "" + getStatus() + "\n" + getQuestionID() + "\n" + getQuestion() + "\n" + getAnswer() + "\n" + getValue()
				+ "\n";
	}

}
