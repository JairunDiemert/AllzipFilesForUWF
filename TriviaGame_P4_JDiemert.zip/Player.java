import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**The Player class stores player info into a file
 * 
 * @author Jairun Diemert
 * @version 1.0
 * 
 * COP3022 Project #: 4 
 * File Name: Player.java
 */
public class Player {
	
	/**Name of player
	 * 
	 */
	private String realName;
	
	/**Nick Name of player
	 * 
	 */
	private String nickName;
	
	/**Score of player
	 * 
	 */
	private String totalScore = "0";

	/**default constructor
	 * 
	 */
	public Player() {
		setRealName("null");
		setNickName("null");
		setTotalScore("0");
	}

	/**Parameterized constructor
	 * @param realName player name
	 * @param nickName player nick name
	 */
	public Player(String realName, String nickName) {
		setRealName(realName);
		setNickName(nickName);
		setTotalScore("0");
		writeUsingFileWriter();
	}

	/** Parameterized constructor used for returning players 
	 * @param realName player name
	 * @param nickName player nick name
	 * @param score player score
	 */
	public Player(String realName, String nickName, String score) {
		setRealName(realName);
		setNickName(nickName);
		setTotalScore(score);
		writeUsingFileWriter();
	}

	/**saves player info into .dat file
	 * 
	 */
	private void writeUsingFileWriter() {
		String data = "";
		data = toString();
		String fileName = "" + getRealName() + ".dat";
		File file = new File(fileName);
		FileWriter fr = null;
		try {
			fr = new FileWriter(file);
			fr.write(data);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			// close resources
			try {
				fr.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**returns players real name
	 * @return real name string
	 */
	public String getRealName() {
		return realName;
	}

	/**set the name of player
	 * @param realName name string
	 */
	private void setRealName(String realName) {
		this.realName = realName;
	}

	/**return nick name
	 * @return nick name string
	 */
	public String getNickName() {
		return nickName;
	}

	/** set nick name 
	 * @param nickName nick name string
	 */
	private void setNickName(String nickName) {
		this.nickName = nickName;
	}

	/** return score
	 * @return score 
	 */
	public String getTotalScore() {
		return totalScore;
	}

	/**set total score
	 * @param totalScore score
	 */
	private void setTotalScore(String totalScore) {
		this.totalScore = totalScore;
	}

	/**returns player info
	 *
	 */
	@Override
	public String toString() {
		return "" + getRealName() + "," + getNickName() + "," + getTotalScore() + ",\n";
	}

}
