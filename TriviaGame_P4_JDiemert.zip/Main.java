import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

/**The Main class tests the package
 * 
 * @author Jairun Diemert
 * @version 1.0
 * 
 * COP3022 Project #: 4 
 * File Name: Main.java
 */
public class Main {

	public static void main(String[] args) throws IOException {
		String option = "";
		String name = "";
		String nickName = "";
		String score = "0";
		String currentScore = "0";
		String fileName;
		String fileName2 = "questions.dat";
		Player newPlayer = null;
		TriviaGame game = new TriviaGame();
		game.getQuestionsFromFile(fileName2);
		boolean done = false;
		boolean result = false;
		boolean done2 = false;
		boolean done3 = false;
		boolean done4 = false;
		boolean stop = false;
		Scanner in = new Scanner(System.in);

		do {
			done = false;
			result = false;
			done2 = false;
			done3 = false;
			stop = false;
			do {
				System.out.print("(P)Play Game or (O)Options: ");
				option = in.nextLine();
				switch (option.charAt(0)) {
				case 'p':
				case 'P':
					done4 = true;
					break;
				case 'o':
				case 'O':
					game.adminMenu(in);
					break;
				default:
					System.out.println("Invalid Entry");
					break;
				}

			} while (!done4);

			do {
				System.out.print("New player (N) or Existing player (E): ");
				option = in.nextLine();
				switch (option.charAt(0)) {
				case 'n':
				case 'N':
					System.out.print("Enter name: ");
					name = in.nextLine();
					System.out.print("Enter nick name: ");
					nickName = in.nextLine();
					newPlayer = new Player(name, nickName);
					done2 = true;
					break;
				case 'e':
				case 'E':
					while (!done) {
						try {

							System.out.print("Enter name: ");
							name = in.nextLine();
							fileName = "" + name + ".dat";
							// Attempt to open the file
							FileInputStream file = new FileInputStream(fileName);
							Scanner fileIn = new Scanner(file);
							fileIn.useDelimiter(",|/|\r\n");// set delimiter to comma or end of line.
							name = fileIn.next();
							nickName = fileIn.next();
							score = fileIn.next();
							System.out.println("\nFile info\n" + "~~~~~~~~~~~~\n" + "Name: " + name + "\n"
									+ "Nick Name: " + nickName + "\n" + "Score: " + score);
							newPlayer = new Player(name, nickName, score);
							done = true;
							file.close();
							fileIn.close();
						} catch (FileNotFoundException e) {
							System.out.println("File not found.");
						}
					}
					done2 = true;
					break;
				default:
					System.out.println("Invalid Entry");
					break;
				}
			} while (!done2);

			do {
				for (int i = 0; i < 5; i++) {
					System.out.println(game.getRandomQuestion());
					result = game.checkAnswer(in.nextLine());
					if (result) {
						score = String.valueOf(Integer.parseInt(score)
								+ Integer.parseInt(game.getqArrayVar(game.getIndex()).getValue()));
						currentScore = String.valueOf(Integer.parseInt(currentScore)
								+ Integer.parseInt(game.getqArrayVar(game.getIndex()).getValue()));
					}
					System.out.println("Your score is " + score);
				}
				System.out.print("Play again (Y or N):");
				option = in.nextLine();
				switch (option.charAt(0)) {
				case 'n':
				case 'N':
					stop = true;
					break;
				default:
					break;
				}
			} while (!stop);
			System.out.println("\nNickName: " + newPlayer.getNickName() + "\nCurrent Game Score: " + currentScore
					+ "\nTotal Score: "
					+ String.valueOf(Integer.parseInt(newPlayer.getTotalScore()) + Integer.parseInt(currentScore)));
			newPlayer = new Player(newPlayer.getRealName(), newPlayer.getNickName(),
					String.valueOf(Integer.parseInt(newPlayer.getTotalScore()) + Integer.parseInt(currentScore)));
			System.out.print("\n(C)Continue or (Q)Quit:");
			option = in.nextLine();
			switch (option.charAt(0)) {
			case 'q':
			case 'Q':
				done3 = true;
				break;
			default:
				break;
			}

		} while (!done3);
		in.close();

	}

}
