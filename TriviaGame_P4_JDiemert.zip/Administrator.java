import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**The Administrator class manipulates a question list
 * 
 * @author Jairun Diemert
 * @version 1.0
 * 
 * COP3022 Project #: 4 
 * File Name: Administrator.java
 */

public class Administrator {
	
	/**an array of questions
	 * 
	 */
	private Questions[] qArray;
	
	/**Opens a administrator menu
	 * @param in Scanner for user input
	 */
	public void adminMenu(Scanner in) {

		Boolean stop = false;
		String option = "";
		String questionID;

		do {
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.println("\n\nTrivia Game Administration\n");
			System.out.println("   1. List all questions");
			System.out.println("   2. Add question");
			System.out.println("   3. Delete question");
			System.out.println("   4. Find a question by question ID number");
			System.out.println("   5. Quit the Administrator");
			System.out.print("\nEnter choice: ");

			option = in.nextLine();
			System.out.println("\n");
			switch (option.charAt(0)) {
			case '1':
				listQuestions();
				break;
			case '2':
				addQuestion(in);
				break;
			case '3':
				System.out.print("\nEnter Question ID#: ");
				questionID = in.nextLine();
				deleteQuestion(questionID);
				break;
			case '4':
				System.out.print("\nEnter Question ID#: ");
				questionID = in.nextLine();
				findQuestion(questionID);
				break;
			case '5':
				stop = true;
				System.out.print("Would you like to save your Questions list?\n (Enter Y for yes & N for no): ");
				option = in.nextLine();
				switch (option.charAt(0)) {
				case 'y':
				case 'Y':
					writeUsingFileWriter();
					System.out.println("New question list saved");
					break;
				default:
					System.out.println("Original question list maintained");
					break;
				}
				System.out.println("Admin Menu Exited");
				break;
			default:
				System.out.println("Invalid Entry");
				break;
			}
		} while (!stop);
	}

	/**returns a question variable from question array
	 * @param i int index
	 * @return question
	 */
	public Questions getqArrayVar(int i) {
		return qArray[i];
	}

	/**returns an array of questions
	 * @return array
	 */
	public Questions[] getqArray() {
		return qArray;
	}

	/**Pulls a list of questions into a question element and stores the list in an array
	 * @param questions File name of file questions are stored
	 */
	public void getQuestionsFromFile(String questionsFile) {
		Scanner fileIn = null; // Initializes fileIn to an empty object
		try {
			// Attempt to open the file
			FileInputStream file = new FileInputStream(questionsFile);
			fileIn = new Scanner(file);
		} catch (FileNotFoundException e) {
			// If the file could not be found, this code is executed
			// and then the program exits
			System.out.println("File not found.");
			System.exit(0);
		}
		String qStatus = "";
		String qID = "";
		String qSentence = "";
		String qAnswer = "";
		String qValue = "";
		Questions qTemp = null;
		int counterArray = 0;
		final int Max_Questions = 20;
		int shiftQuestionNumber = 0;
		Questions[] qArray = new Questions[Max_Questions];
		while (fileIn.hasNextLine() && counterArray < Max_Questions) {
			qStatus = fileIn.nextLine();
			if (qStatus.charAt(0) == 'D') {
				--shiftQuestionNumber;
			}
			qID = String.valueOf(Integer.parseInt(fileIn.nextLine()) + shiftQuestionNumber);
			qSentence = fileIn.nextLine();
			qAnswer = fileIn.nextLine();
			qValue = fileIn.nextLine();
			qTemp = new Questions(qStatus, qID, qSentence, qAnswer, qValue);
			if (!(qStatus.charAt(0) == 'D')) {
				qArray[counterArray] = qTemp;
				++counterArray;
			}

		}
		Questions[] qArrayCopy = new Questions[counterArray];
		for (int i = 0; i < counterArray; i++) {
			qArrayCopy[i] = qArray[i];
		}
		fileIn.close();
		setQArray(qArrayCopy);
	}

	/**set the question array
	 * @param qArray array of questions
	 */
	private void setQArray(Questions[] qArray) {
		this.qArray = qArray;
	}

	/**adds a new question to the question array
	 * @param in Scanner 
	 */
	private void addQuestion(Scanner in) {
		try {
			if (qArray.length > 19) {
				throw new Exceptions("Questions at MAX! Cant have more than 20 Questions.");
			}
			String qStatus = "";
			String qID = "";
			String qSentence = "";
			String qAnswer = "";
			String qValue = "";
			boolean stop = false;
			Questions qTemp = null;
			qStatus = "A";
			qID = String.valueOf(Integer.parseInt(qArray[qArray.length - 1].getQuestionID()) + 1);
			System.out.print("Enter a question to add: ");
			qSentence = in.nextLine();
			System.out.print("Enter the answer: ");
			qAnswer = in.nextLine();
			do {
				try {
					qValue = setValue(in);
					stop = true;
				} catch (Exceptions e) {
					System.out.print("\n" + e.getMessage() + "\n\n");
				}
			} while (!stop);
			qTemp = new Questions(qStatus, qID, qSentence, qAnswer, qValue);
			Questions[] qArrayCopy = new Questions[qArray.length + 1];
			for (int i = 0; i < qArray.length; i++) {
				qArrayCopy[i] = qArray[i];
			}
			qArrayCopy[qArray.length] = qTemp;
			setQArray(qArrayCopy);
		} catch (Exceptions e) {
			System.out.println("\n" + e.getMessage() + "\n");
		}

	}

	/**confirms is value of question is 1-5
	 * @param in Scanner
	 * @return returns the value entered if it is with in the restrictions
	 * @throws Exceptions throws exception if not in restrictions
	 */
	private String setValue(Scanner in) throws Exceptions {
		String qValue = "";
		System.out.print("Enter the questions value: ");
		qValue = in.nextLine();
		switch (qValue.charAt(0)) {
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
			break;
		default:
			throw new Exceptions("Value must be 1-5");
		}
		return qValue;
	}

	/**deletes a question from the question array, shifts the question ID and shrinks the array
	 * @param questionID search index 
	 */
	private void deleteQuestion(String questionID) {
		int index = findQuestion(questionID);
		if (index > -1) {
			for (int i = index; i < qArray.length - 1; ++i) {
				qArray[i] = qArray[i + 1];
				qArray[i].setQuestionID(String.valueOf(Integer.parseInt(qArray[i].getQuestionID()) - 1));
			}
		}
		Questions[] qArrayCopy = new Questions[qArray.length - 1];
		for (int i = 0; i < qArray.length - 1; i++) {
			qArrayCopy[i] = qArray[i];
		}
		setQArray(qArrayCopy);
		System.out.println("Question " + questionID + " Deleted !\n");
	}

	/**searches the question array for a question
	 * @param questionID index for search
	 * @return index of array
	 */
	private int findQuestion(String questionID) {
		try {
			if (!(Integer.parseInt(questionID) > 0 && Integer.parseInt(questionID) < qArray.length + 1)) {
				throw new Exceptions("Question selection must range from 1-" + (qArray.length));
			}
			int index = Integer.parseInt(questionID) - 1;

			System.out.println("\n" + qArray[index]);
			return index;
		} catch (Exceptions e) {
			System.out.println("\n" + e.getMessage() + "\n");
		}
		return -1;
	}

	/**creates a file with new question list after manipulation 
	 * 
	 */
	private void writeUsingFileWriter() {
		String data = "";
		for (int i = 0; i < qArray.length; i++) {
			data = data + qArray[i];
		}
		File file = new File("FileWriter.dat");
		FileWriter fr = null;
		try {
			fr = new FileWriter(file);
			fr.write(data);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			// close resources
			try {
				fr.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/** prints out the iterates through the question array
	 *
	 */
	private void listQuestions() {
		for (int i = 0; i < qArray.length; i++) {
			System.out.println(qArray[i]);
		}
	}
}
