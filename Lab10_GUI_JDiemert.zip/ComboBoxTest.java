
/**
 * The Class ComboBoxFrameTest.
 * 
 * COP3022 Lab #: 10 
 * File Name: ComboBoxFrameTest.java
 * @author Jairun Diemert
 * @version 1.0
 */
public class ComboBoxTest {
	
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		ComboBoxFrame comboBoxFrame = new ComboBoxFrame();
	}
}
