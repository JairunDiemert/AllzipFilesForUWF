
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.ImageIcon;

/**
 * The Class ComboBoxFrame.
 * 
 * COP3022 Lab #: 10 
 * File Name: ComboBoxFrame.java
 * @author Jairun Diemert
 * @version 1.0
 */
public class ComboBoxFrame extends JFrame {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The images panel. */
	private JPanel imagesPanel;
	
	/** The images J combo box. */
	private JComboBox<String> imagesJComboBox;
	
	/** The instruction. */
	private JLabel instruction;
	
	/** The label. */
	private JLabel label;
	
	/** The Constant names. */
	private static final String[] names = { "747.jpg", "707.jpg", "Concorde.jpg" };

	/**
	 * Instantiates a new combo box frame.
	 */
	public ComboBoxFrame() {

		setTitle("Image Viewer");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		setSize(328, 300);
		buildImagesPanel();
		add(imagesPanel);
		setVisible(true);
	}

	/**
	 * Builds the images panel.
	 */
	private void buildImagesPanel() {
		imagesPanel = new JPanel();
		instruction = new JLabel("Select an image to view from the dropdown box below.");
		imagesJComboBox = new JComboBox<String>(names);
		label = new JLabel();
		imagesPanel.add(instruction, BorderLayout.NORTH);
		imagesPanel.add(imagesJComboBox, BorderLayout.CENTER);
		imagesPanel.add(label, BorderLayout.SOUTH);
		imagesJComboBox.addActionListener(new ComboBoxListener());
	}

	/**
	 * The listener interface for receiving comboBox events.
	 * The class that is interested in processing a comboBox
	 * event implements this interface, and the object created
	 * with that class is registered with a component using the
	 * component's <code>addComboBoxListener<code> method. When
	 * the comboBox event occurs, that object's appropriate
	 * method is invoked.
	 *
	 * @see ComboBoxEvent
	 */
	private class ComboBoxListener implements ActionListener {
		
		/**
		 * Action performed.
		 *
		 * @param e the e
		 */
		public void actionPerformed(ActionEvent e) {
			String selection = (String) imagesJComboBox.getSelectedItem();
			ImageIcon image = new ImageIcon(selection);
			label.setIcon(image);
		}
	}
}
