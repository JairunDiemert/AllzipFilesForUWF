/**
The Golfer class handles golfers info
@author Jairun Diemert
@version 1.0

COP3022	Project #: 2
File Name: Golfer.java
*/  
public class Golfer {
	/**
	 * static variable that keeps a unique ID number avlb
	 */
	private static int nextIDNum = 1000;
	/**
	 * Stores the name of the golfer
	 */
	private String name;
	/**
	 * Stores the homeCourse name
	 */
	private String homeCourse;
	/**
	 * stores the ID number
	 */
	private int idNum;
	/**
	 * Increments with every entry into array
	 */
	private int numScores;
	/**
	 * static int holding max array size
	 */
	private final static int MAX_SIZE = 10;
	/**
	 * array that holds objects of Score
	 */
	private Score[] score;

	/**
	 * Default constructor
	 */
	public Golfer() {
		this.name = "Unknown";
		this.homeCourse = "Empty";
		this.idNum = Golfer.nextIDNum;
		++Golfer.nextIDNum;
		this.numScores = 0;
		this.score = new Score[MAX_SIZE];
	}

	/**Parameterized constructor
	 * @param name golfer name provided by user
	 * @param homeCourse home course name provided by user
	 */
	public Golfer(String name, String homeCourse) {
		this.name = name;
		this.homeCourse = homeCourse;
		this.idNum = Golfer.nextIDNum;
		++Golfer.nextIDNum;
		this.numScores = 0;
		this.score = new Score[MAX_SIZE];
	}

	/** returns name of golfer
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**set name of golfer from user parameter 
	 * @param name golfer name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**returns the home course
	 * @return home course
	 */
	public String getHomeCourse() {
		return homeCourse;
	}

	/**set home course from user parameter
	 * @param homeCourse home course
	 */
	public void setHomeCourse(String homeCourse) {
		this.homeCourse = homeCourse;
	}

	/**returns ID number
	 * @return ID number
	 */
	public int getIdNum() {
		return idNum;
	}

	/**
	 * sets ID number from incremented static variable nextIDNum
	 */
	public void setIdNum() {
		this.idNum = Golfer.nextIDNum;
		++Golfer.nextIDNum;
	}

	/**adds an object of class Score
	 * @param score Object of class score
	 */
	public void addScore(Score score) {
		this.score[this.numScores] = score;
		++this.numScores;
	}

	/**delete score object from array and shift 
	 * @param date search parameter from user
	 * @return true or false if deleted 
	 */
	public Boolean deleteScore(String date) {
		Boolean temp = false;
		if (findScore(date) > -1) {
			for (int i = findScore(date); i < this.numScores; ++i) {
				this.score[i] = this.score[i + 1];
			}
			temp = true;
			--this.numScores;
		}
		return temp;
	}

	/**returns score is available from user parameter 
	 * @param date date parameter
	 * @return score
	 */
	public Score getScore(String date) {
		Score temp = null;
		if (findScore(date) > -1) {
			temp = this.score[findScore(date)];
		}
		return temp;
	}

	/**finds score by user date parameter 
	 * @param date user input
	 * @return index of array location
	 */
	private int findScore(String date) {
		int index = -1;
		String temp = new String();
		for (int i = 0; i < this.numScores; ++i) {
			temp = "" + this.score[i];
			if (temp.contains(date)) {
				index = i;
			}
		}
		return index;
	}

	/**returns lowest score out of array
	 * @return lowest Score object 
	 */
	public Score lowestScore() {
		Score temp = null;
		int index = -1;
		if (this.numScores > 0) {
			index = 0;
			int min = this.score[0].getScore();
			for (int i = 0; i < this.numScores; ++i) {
				if (this.score[i + 1] != null && min > this.score[i + 1].getScore()) {
					min = this.score[i + 1].getScore();
					index = i + 1;
				}
			}
			temp = this.score[index];
		}
		return temp;
	}

	/**
	 * Reference override and converted to string
	 */
	@Override
	public String toString() {

		String temp = new String();
		for (int i = 0; i < this.numScores; ++i) {
			temp = temp + this.score[i] + "\n";
		}
		return "______________________________________________________________________________\n" + name
				+ "   ID number: " + idNum + "   Home Course: " + homeCourse
				+ "\n\nScore   Date         Course    CR      CS\n---------------------------"
				+ "-------------------------\n" + temp;
	}

}
