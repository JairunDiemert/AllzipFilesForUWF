/**
The GolfTester class tests the Gold Class
@author Jairun Diemert
@version 1.0

COP3022	Project #: 2
File Name: GolferTester.java
*/  
public class GolferTester {

	public static void main(String[] args) {
		Golfer golfer1 = new Golfer();
		golfer1.addScore(new Score());
		System.out.println(golfer1);

		Golfer golfer2 = new Golfer("Jairun Diemert", "Osceola Municipal Golf Course");
		golfer2.addScore(new Score("Osceola Municipal Golf Course", 60.5, 100, "05/30/19", 150));
		golfer2.addScore(new Score("Long Beach Golf Course", 70.5, 80, "04/30/19", 20));
		golfer2.addScore(new Score("St.Pete Fields", 79.9, 200, "03/30/19", 80));
		golfer2.addScore(new Score("Down Town Drive", 110.7, 94, "02/28/19", 95));

		System.out.println(golfer2);
		golfer2.setName("Percilla Diemert");
		System.out.println("name: " + golfer2.getName() + "\n");
		golfer2.setHomeCourse("Changed my mind field");
		System.out.println("course name: " + golfer2.getHomeCourse() + "\n");
		golfer2.setIdNum();
		System.out.println("IDnum: " + golfer2.getIdNum() + "\n");
		System.out.println("Delete score 04/30/19:" + golfer2.deleteScore("04/30/19") + "\n");
		System.out.println("Score at 04/30/19? " + golfer2.getScore("04/30/19") + "\n");
		System.out.println("low score: " + golfer2.lowestScore() + "\n");
		System.out.println(golfer2);

	}

}
