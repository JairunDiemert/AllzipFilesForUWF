/**
The Score class handles golf scores 
@author Jairun Diemert
@version 1.0

COP3022	Project #: 2
File Name: Score.java
*/  
public class Score {
	/**
	 * course played on
	 */
	private String course;
	/**
	 * ending score
	 */
	private int score; // between 40-200 (inclusive). Set to 9999 if error
	/**
	 * date played
	 */
	private String date; // format mm/dd/yy. Set to 9999 if error
	/**
	 * course rating 
	 */
	private double courseRating; // between 60-80 (inclusive). Set to 9999 if error
	/**
	 * course slope 
	 */
	private int courseSlope; // between 55-155 (inclusive). Set to 9999 if error

	/**
	 * Default constructor for Score class
	 */
	public Score() {
		this.course = "NoName";
		this.score = -3;
		this.date = "00/00/00";
		this.courseRating = -1.1;
		this.courseSlope = -2;
	}

	/**Parameterized constructor 
	 * @param course course played on 
	 * @param courseRating course rating 
	 * @param courseSlope course slope
	 * @param date date played
	 * @param score ending score 
	 */
	public Score(String course, double courseRating, int courseSlope, String date, int score) {
		this.course = course;
		if (score > 40 && score < 200) {
			this.score = score;
		} else {
			System.out.println("score must be between 40-200 (inclusive). Set to 9999");
			this.score = 9999;
		}
		this.date = date;
		if (courseRating > 60 && courseRating < 80) {
			this.courseRating = courseRating;
		} else {
			System.out.println("courseRating must be between 60-80 (inclusive). Set to 9999");
			this.courseRating = 9999;
		}
		if (courseSlope > 55 && courseSlope < 155) {
			this.courseSlope = courseSlope;
		} else {
			System.out.println("courseSlope must be between 55-155 (inclusive). Set to 9999");
			this.courseSlope = 9999;
		}

	}

	/**returns the course name
	 * @return course name
	 */
	public String getCourse() {
		return course;
	}

	/**sets the course name from user parameter 
	 * @param course name of course 
	 */
	public void setCourse(String course) {
		this.course = course;
	}

	/**Returns score 
	 * @return score 
	 */
	public int getScore() {
		return score;
	}

	/**sets the score from user parameter 
	 * @param score end score 
	 */
	public void setScore(int score) {
		this.score = score;
	}

	/**returns the date played
	 * @return date
	 */
	public String getDate() {
		return date;
	}

	/**Sets the date from user parameter
	 * @param date date
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**returns the course rating 
	 * @return course rating 
	 */
	public double getCourseRating() {
		return courseRating;
	}

	/**Set the course rating from user parameter 
	 * @param courseRating course rating 
	 */
	public void setCourseRating(double courseRating) {
		this.courseRating = courseRating;
	}

	/**returns course slope
	 * @return course slope 
	 */
	public int getCourseSlope() {
		return courseSlope;
	}

	/**Set the course slope from user parameter
	 * @param courseSlope course slope
	 */
	public void setCourseSlope(int courseSlope) {
		this.courseSlope = courseSlope;
	}

	/**
	 *override reference to string 
	 */
	@Override
	public String toString() {
		return "" + score + "     " + date + "     " + course + "     " + courseRating + "     " + courseSlope;
	}

}